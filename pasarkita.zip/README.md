# PasarKita - Marketplace PHP Native

Aplikasi marketplace sederhana menggunakan **PHP Native, MySQLi, MySQL, dan Bootstrap 5**.

## Fitur
- Daftar produk, pencarian, filter kategori, dan detail produk.
- Keranjang belanja berbasis PHP Session (tambah, ubah jumlah, hapus).
- Checkout dan penyimpanan transaksi ke tabel `orders` dan `order_items`.
- Penguncian stok (`SELECT ... FOR UPDATE`) dan transaksi database saat checkout.
- Registrasi dan login Pembeli (BUYER) serta Penjual (SELLER).
- Login Admin (ADMIN) dengan akun awal dari installer.
- Dashboard penjual untuk mengelola produk miliknya; admin tetap dapat mengelola seluruh produk.
- Riwayat pesanan pembeli.
- Prepared statements, escaping output, dan token CSRF pada form POST.

## Persyaratan
- PHP 8.1+ dengan ekstensi `mysqli`, `fileinfo`, dan `mbstring`.
- MySQL 5.7+/MariaDB 10.4+.
- XAMPP/Laragon atau hosting PHP + MySQL.

## Menjalankan di XAMPP
1. Salin folder `marketplace_php_native` ke `C:/xampp/htdocs/`.
2. Nyalakan Apache dan MySQL dari XAMPP Control Panel.
3. Buka phpMyAdmin (`http://localhost/phpmyadmin`) dan gunakan database `marketplace_php_native` (database ini sesuai konfigurasi lokal yang sudah dipakai pada pengujian XAMPP).
4. Jika database belum memiliki tabel, pilih database tersebut lalu impor `database/schema.sql`.
5. Jika database sudah berisi tabel dan akun, backup terlebih dahulu lalu jalankan `database/update_database.sql` untuk menyelaraskan kolom `phone`, `password_hash`, dan enum `role` tanpa menghapus data akun.
6. File `config/config.php` lokal sudah diarahkan ke database `marketplace_php_native` dengan host `localhost`, user `root`, dan password kosong. Biarkan `base_url` kosong agar subfolder XAMPP terdeteksi otomatis.
7. Buka URL installer sesuai lokasi folder project, misalnya `http://localhost/pasarkita1/marketplace_php_native/install.php` untuk membuat akun contoh, kategori, dan data produk.
8. Setelah berhasil, hapus `install.php`.
9. Buka `http://localhost/pasarkita1/marketplace_php_native/`.

### Akun awal setelah menjalankan installer
- Admin: `admin@pasarkita.test` / `Admin123!` (login khusus melalui `/admin/login.php`).
- Penjual demo: `seller@pasarkita.test` / `Seller123!` (login melalui `/auth/login.php`, pilih Penjual).
- Pembeli: buat akun sendiri melalui `/auth/register.php`.

Pengguna baru hanya dapat mendaftar sebagai Pembeli (`BUYER`) atau Penjual (`SELLER`) melalui `/auth/register.php`. Login umum `/auth/login.php` hanya menerima Pembeli dan Penjual. Admin masuk melalui halaman terpisah `/admin/login.php`; registrasi Admin tidak tersedia untuk umum.

Segera ubah password admin jika aplikasi akan dipakai secara publik. Kredensial awal hanya untuk demonstrasi tugas.

## Struktur database
1. `users`: akun ADMIN, SELLER, dan BUYER.
2. `categories`: kategori produk.
3. `products`: data produk, terhubung ke kategori dan penjual.
4. `orders`: data utama pesanan dan informasi pengiriman.
5. `order_items`: rincian produk pada masing-masing pesanan (menyimpan snapshot nama dan harga).

Relasi penting: `products.category_id` → `categories.id`, `products.seller_id` → `users.id`, `orders.buyer_id` → `users.id`, `order_items.order_id` → `orders.id`, dan `order_items.product_id` → `products.id`.

Keranjang disimpan di PHP Session. Checkout mewajibkan akun Pembeli yang sudah login. Saat checkout, data keranjang divalidasi ulang dan pesanan disimpan dalam transaksi MySQL. Penjual mengelola produk miliknya melalui `/seller/dashboard.php` dan `/seller/products.php`; Admin mengelola semua produk melalui `/admin/`; Pembeli melihat riwayat pesanan melalui `/buyer/orders.php`.

## Deploy ke InfinityFree
1. Buat akun dan hosting gratis di https://infinityfree.com.
2. Dari Control Panel, buat database MySQL dan catat hostname, nama database, username, serta password.
3. Buka Online File Manager atau FTP. Unggah **isi folder project** ke `htdocs` (bukan folder pembungkusnya).
4. Salin `config/config.example.php` menjadi `config/config.php` di hosting lalu masukkan detail database InfinityFree. Isi `base_url` dengan URL demo tanpa slash akhir, misalnya `https://nama-akun.infinityfreeapp.com`.
5. Impor `database/schema.sql` melalui phpMyAdmin setelah memilih database yang baru dibuat. File SQL ini hanya membuat tabel, bukan database. Jalankan `https://URL-DEMO/install.php` untuk seed akun admin, toko demo, kategori, dan produk contoh.
6. Pastikan folder `uploads` dapat ditulisi. Uji katalog, gambar, CRUD, dan checkout.
7. Hapus `install.php` setelah instalasi.

**Catatan InfinityFree:** gunakan nilai **MySQL Host Name** yang ditampilkan di Control Panel, bukan `localhost`; nama database, username, dan password juga harus disalin dari bagian MySQL Databases. Database dibuat dari panel, kemudian tabel diimpor melalui phpMyAdmin. Folder website diunggah ke `htdocs`.

## Publikasi GitHub dengan aman
1. Buat repository baru di GitHub.
2. Jangan unggah `config/config.php`, kata sandi, file `.env`, atau kredensial hosting. `.gitignore` sudah mengecualikan file konfigurasi lokal dan isi folder uploads.
3. Inisialisasi dan push:

```bash
git init
git add .
git commit -m "Initial commit: PasarKita marketplace"
git branch -M main
git remote add origin https://github.com/USERNAME/REPOSITORY.git
git push -u origin main
```

4. Commit `config/config.example.php` saja sebagai contoh konfigurasi.

## Pengujian minimum
- Buka daftar produk dan filter kategori/cari produk.
- Buka detail produk, masukkan produk ke keranjang.
- Ubah jumlah dan hapus item di keranjang.
- Checkout dengan nama, email, telepon, dan alamat yang valid.
- Pastikan halaman sukses menampilkan kode pesanan.
- Verifikasi record pada `orders` dan `order_items`, serta stok produk berkurang.
- Registrasi Pembeli dan Penjual; pastikan role tersimpan sebagai `BUYER` dan `SELLER`.
- Login Pembeli/Penjual melalui `/auth/login.php`; pastikan Admin tidak tersedia di pilihan umum.
- Login Admin melalui `/admin/login.php`; pastikan akun Pembeli/Penjual tidak dapat masuk ke area Admin.
- Penjual menambah/mengubah/menonaktifkan produk miliknya; pastikan tidak dapat mengubah produk milik penjual lain.
- Admin mengelola seluruh produk; Pembeli membuat pesanan dan melihat riwayat pesanan.

## Batasan versi tugas
- Pembayaran belum terhubung ke payment gateway; status awal pesanan `BARU`.
- Keranjang menggunakan session browser, tidak tersinkron antar perangkat.
- Belum ada dashboard pelanggan / pelacakan pesanan login.


## Login, Daftar, dan Logout

- Halaman login pembeli/penjual: `auth/login.php`
- Halaman pendaftaran pembeli/penjual: `auth/register.php`
- Login khusus admin: `admin/login.php`
- Logout semua role: `logout.php` (URL utama: `/marketplace_php_native/logout.php`)
- Link internal dibuat melalui helper `url()` agar tidak menghasilkan URL dengan folder ganda atau `//`.
- File `auth/logout.php` dan `admin/logout.php` tetap tersedia sebagai kompatibilitas dan meneruskan ke logout utama.
