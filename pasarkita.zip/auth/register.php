<?php
require __DIR__ . '/../config/database.php';
require __DIR__ . '/../includes/functions.php';

if (current_user()) {
    auth_redirect();
}

$errors = [];
$role = strtoupper($_GET['role'] ?? 'BUYER');
if (!in_array($role, ['BUYER', 'SELLER'], true)) {
    $role = 'BUYER';
}

$name = '';
$email = '';
$phone = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $name = trim($_POST['name'] ?? '');
    $email = strtolower(trim($_POST['email'] ?? ''));
    $phone = trim($_POST['phone'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';
    $role = strtoupper($_POST['role'] ?? '');

    // Role dibatasi di server; perubahan pilihan dari browser tidak bisa membuat Admin.
    if (!in_array($role, ['BUYER', 'SELLER'], true)) {
        $errors[] = 'Jenis akun tidak valid. Pilih Pembeli atau Penjual.';
    }
    if ($name === '' || mb_strlen($name) > 120) {
        $errors[] = 'Nama wajib diisi (maksimal 120 karakter).';
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || mb_strlen($email) > 160) {
        $errors[] = 'Format email tidak valid (maksimal 160 karakter).';
    }
    if ($phone !== '' && mb_strlen($phone) > 30) {
        $errors[] = 'Nomor telepon maksimal 30 karakter.';
    }
    if (strlen($password) < 8) {
        $errors[] = 'Password minimal 8 karakter.';
    }
    if ($password !== $confirm) {
        $errors[] = 'Konfirmasi password tidak sama.';
    }

    if (!$errors) {
        $hash = password_hash($password, PASSWORD_DEFAULT);

        try {
            $stmt = $conn->prepare(
                'INSERT INTO users (name, email, phone, password_hash, role) VALUES (?, ?, NULLIF(?, \'\'), ?, ?)'
            );
            $stmt->bind_param('sssss', $name, $email, $phone, $hash, $role);
            $stmt->execute();

            $newUserId = (int) $conn->insert_id;
            $stmt->close();

            session_regenerate_id(true);
            unset($_SESSION['admin']);
            $_SESSION['user'] = [
                'id' => $newUserId,
                'name' => $name,
                'email' => $email,
                'phone' => $phone,
                'role' => $role,
            ];

            set_flash('success', 'Pendaftaran sebagai ' . ($role === 'SELLER' ? 'Penjual' : 'Pembeli') . ' berhasil.');
            auth_redirect();
        } catch (mysqli_sql_exception $e) {
            if ((int) $e->getCode() === 1062) {
                $errors[] = 'Email sudah terdaftar. Gunakan email lain atau silakan login.';
            } else {
                error_log('Register error: ' . $e->getMessage());
                $errors[] = 'Pendaftaran gagal karena data belum sesuai dengan database. Periksa struktur tabel users atau jalankan file database/update_database.sql.';
            }
        }
    }
}

render_header('Daftar PasarKita');
?>
<div class="row justify-content-center">
    <div class="col-md-8 col-lg-6">
        <form method="post" class="panel p-4 p-lg-5">
            <?= csrf_field() ?>
            <h1 class="h3 fw-bold">Buat Akun PasarKita</h1>
            <p class="text-secondary">Pilih jenis akun yang ingin kamu gunakan.</p>

            <?php if ($errors): ?>
                <div class="alert alert-danger">
                    <ul class="mb-0">
                        <?php foreach ($errors as $error): ?>
                            <li><?= e($error) ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>

            <div class="mb-3">
                <label class="form-label" for="role">Daftar sebagai</label>
                <select class="form-select" id="role" name="role" required>
                    <option value="BUYER" <?= $role === 'BUYER' ? 'selected' : '' ?>>Pembeli</option>
                    <option value="SELLER" <?= $role === 'SELLER' ? 'selected' : '' ?>>Penjual</option>
                </select>
                <div class="form-text">Akun Admin hanya dapat dibuat oleh pengelola sistem.</div>
            </div>

            <div class="mb-3">
                <label class="form-label" for="name">Nama lengkap / nama toko</label>
                <input class="form-control" id="name" name="name" maxlength="120" required value="<?= e($name) ?>">
            </div>
            <div class="mb-3">
                <label class="form-label" for="email">Email</label>
                <input class="form-control" id="email" type="email" name="email" maxlength="160" required value="<?= e($email) ?>">
            </div>
            <div class="mb-3">
                <label class="form-label" for="phone">Nomor telepon (opsional)</label>
                <input class="form-control" id="phone" name="phone" maxlength="30" value="<?= e($phone) ?>">
            </div>
            <div class="mb-3">
                <label class="form-label" for="password">Password</label>
                <input class="form-control" id="password" type="password" name="password" minlength="8" required autocomplete="new-password">
            </div>
            <div class="mb-4">
                <label class="form-label" for="confirm_password">Konfirmasi password</label>
                <input class="form-control" id="confirm_password" type="password" name="confirm_password" minlength="8" required autocomplete="new-password">
            </div>

            <button class="btn btn-brand w-100" type="submit">Daftar</button>
            <p class="text-center mt-3 mb-0">Sudah punya akun? <a href="<?= e(url('auth/login.php')) ?>">Login</a></p>
        </form>
    </div>
</div>
<?php render_footer(); ?>
