<?php
require __DIR__ . '/../config/database.php';
require __DIR__ . '/../includes/functions.php';

if (current_user()) {
    auth_redirect();
}

$error = '';
$role = strtoupper($_GET['role'] ?? 'BUYER');
if (!in_array($role, ['BUYER', 'SELLER'], true)) {
    $role = 'BUYER';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $email = strtolower(trim($_POST['email'] ?? ''));
    $password = $_POST['password'] ?? '';
    $role = strtoupper($_POST['role'] ?? '');

    if (!in_array($role, ['BUYER', 'SELLER'], true)) {
        $error = 'Silakan pilih jenis akun Pembeli atau Penjual.';
    } else {
        $stmt = $conn->prepare(
            'SELECT id, name, email, phone, password_hash, role FROM users WHERE email = ? AND role = ? LIMIT 1'
        );
        $stmt->bind_param('ss', $email, $role);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if ($user && !empty($user['password_hash']) && password_verify($password, $user['password_hash'])) {
            session_regenerate_id(true);
            unset($_SESSION['admin']);
            $_SESSION['user'] = [
                'id' => (int) $user['id'],
                'name' => $user['name'],
                'email' => $user['email'],
                'phone' => $user['phone'],
                'role' => $user['role'],
            ];
            auth_redirect();
        }

        $error = 'Email, password, atau jenis akun tidak sesuai.';
    }
}

render_header('Login PasarKita');
?>
<div class="row justify-content-center">
    <div class="col-md-7 col-lg-5">
        <form method="post" class="panel p-4 p-lg-5">
            <?= csrf_field() ?>
            <h1 class="h3 fw-bold">Login PasarKita</h1>
            <p class="text-secondary">Masuk sesuai jenis akun yang kamu miliki.</p>

            <?php if ($error): ?>
                <div class="alert alert-danger"><?= e($error) ?></div>
            <?php endif; ?>

            <div class="mb-3">
                <label class="form-label" for="role">Masuk sebagai</label>
                <select class="form-select" id="role" name="role" required>
                    <option value="BUYER" <?= $role === 'BUYER' ? 'selected' : '' ?>>Pembeli</option>
                    <option value="SELLER" <?= $role === 'SELLER' ? 'selected' : '' ?>>Penjual</option>
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label" for="email">Email</label>
                <input class="form-control" id="email" type="email" name="email" required autocomplete="username" value="<?= e($_POST['email'] ?? '') ?>">
            </div>
            <div class="mb-4">
                <label class="form-label" for="password">Password</label>
                <input class="form-control" id="password" type="password" name="password" required autocomplete="current-password">
            </div>

            <button class="btn btn-brand w-100" type="submit">Login</button>
            <p class="text-center mt-3 mb-0">Belum punya akun? <a href="<?= e(url('auth/register.php')) ?>">Daftar sekarang</a></p>
            <p class="text-center mt-2 mb-0 small"><a href="<?= e(url('admin/login.php')) ?>">Login khusus Admin</a></p>
        </form>
    </div>
</div>
<?php render_footer(); ?>
