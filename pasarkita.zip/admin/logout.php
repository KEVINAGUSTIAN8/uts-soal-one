<?php
require __DIR__ . '/../includes/functions.php';
redirect('logout.php');
