<?php
require __DIR__ . '/config/database.php';
require __DIR__ . '/includes/functions.php';
$messages=[];
try {
 $sql=file_get_contents(__DIR__.'/database/schema.sql');
 // Jalankan DDL per statement pada database yang sudah dipilih di config.
 foreach(array_filter(array_map('trim', explode(';',$sql))) as $statement){
  // Database sudah dipilih di config/config.php; abaikan CREATE DATABASE dan USE agar kompatibel dengan hosting shared.
  if($statement==='' || preg_match('/^(CREATE\s+DATABASE|USE\s+)/i',$statement)) continue;
  $conn->query($statement);
 }
 $adminEmail='admin@pasarkita.test'; $adminName='Administrator PasarKita'; $adminPass=password_hash('Admin123!', PASSWORD_DEFAULT);
 $stmt=$conn->prepare("INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,'ADMIN') ON DUPLICATE KEY UPDATE name=VALUES(name), password_hash=IF(role='ADMIN',VALUES(password_hash),password_hash)"); $stmt->bind_param('sss',$adminName,$adminEmail,$adminPass); $stmt->execute();
 $sellerEmail='seller@pasarkita.test'; $sellerName='Toko Demo'; $sellerPass=password_hash('Seller123!', PASSWORD_DEFAULT); $stmt=$conn->prepare("INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,'SELLER') ON DUPLICATE KEY UPDATE name=VALUES(name), password_hash=IF(role='SELLER',VALUES(password_hash),password_hash)"); $stmt->bind_param('sss',$sellerName,$sellerEmail,$sellerPass); $stmt->execute(); $sellerId=(int)$conn->query("SELECT id FROM users WHERE email='seller@pasarkita.test'")->fetch_assoc()['id'];
 $categories=['Elektronik','Fashion','Rumah Tangga','Makanan']; $categoryIds=[];
 $stmt=$conn->prepare('INSERT INTO categories(name) VALUES(?) ON DUPLICATE KEY UPDATE id=LAST_INSERT_ID(id)');
 foreach($categories as $cat){$stmt->bind_param('s',$cat);$stmt->execute();$categoryIds[$cat]=$conn->insert_id ?: (int)$conn->query("SELECT id FROM categories WHERE name='".$conn->real_escape_string($cat)."'")->fetch_assoc()['id'];}
 $count=(int)$conn->query('SELECT COUNT(*) AS c FROM products')->fetch_assoc()['c'];
 if($count===0){$samples=[['Headphone Wireless','Headphone bluetooth untuk aktivitas harian.',250000,15,'Elektronik'],['Kaos Basic Premium','Kaos katun nyaman untuk dipakai sehari-hari.',89000,30,'Fashion'],['Botol Minum 1 Liter','Botol minum praktis untuk sekolah dan kerja.',55000,20,'Rumah Tangga'],['Kopi Bubuk Nusantara','Kopi bubuk pilihan dengan aroma khas.',45000,25,'Makanan']];$p=$conn->prepare('INSERT INTO products(category_id,seller_id,name,description,price,stock,image) VALUES(?,?,?,?,?,?,NULL)');foreach($samples as $x){[$n,$d,$pr,$st,$cat]=$x;$cid=$categoryIds[$cat];$p->bind_param('iissdi',$cid,$sellerId,$n,$d,$pr,$st);$p->execute();}}
 $messages[]='Database, tabel, akun admin, penjual demo, kategori, dan produk contoh berhasil disiapkan.';
} catch(Throwable $e){$messages[]='Instalasi gagal: '.$e->getMessage();}
?><!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Instalasi PasarKita</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"></head><body class="bg-light"><div class="container py-5"><div class="card shadow-sm mx-auto" style="max-width:700px"><div class="card-body p-4"><h1 class="h3">Instalasi PasarKita</h1><?php foreach($messages as $m):?><div class="alert alert-info"><?=e($m)?></div><?php endforeach;?><h2 class="h5">Akun admin awal</h2><p>Email: <code>admin@pasarkita.test</code><br>Password: <code>Admin123!</code></p><p class="text-danger">PENTING: setelah instalasi berhasil, hapus file <code>install.php</code> dari hosting.</p><a class="btn btn-success" href="index.php">Buka marketplace</a></div></div></div></body></html>
