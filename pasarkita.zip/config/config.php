<?php
/**
 * TEMPLATE konfigurasi koneksi database PasarKita (InfinityFree / XAMPP).
 *
 * Cara pakai:
 * 1. Salin file ini menjadi config/config.php
 * 2. Isi nilai di bawah sesuai panel InfinityFree (menu MySQL Databases)
 * 3. JANGAN upload config/config.php ke GitHub (sudah diabaikan oleh .gitignore)
 */

return [
    // --- Contoh untuk InfinityFree (salin persis dari panel MySQL Databases) ---
    'db_host' => 'sql104.infinityfree.com',   // MySQL Host Name, BUKAN localhost
    'db_name' => 'if0_43407499_pasarkita',        // nama database lengkap dengan prefix if0_
    'db_user' => 'if0_43407499',               // MySQL Username
    'db_pass' => '31iSDwVPupPTmv4', // password MySQL / vPanel
    'db_port' => 3306,

    // URL demo tanpa garis miring di akhir, mis. https://nama-akun.infinityfreeapp.com
    // Kosongkan ('') saat dijalankan lokal di XAMPP agar subfolder terdeteksi otomatis.
    'base_url' => '',

    'app_name' => 'PasarKita',
    'timezone' => 'Asia/Jakarta',
];
