-- PasarKita: pembaruan struktur tabel users untuk database yang SUDAH ADA.
-- Jalankan setelah memilih database marketplace_php_native di phpMyAdmin.
-- Backup database terlebih dahulu sebelum menjalankan perubahan.
-- Script ini tidak menghapus data akun yang sudah terdaftar.

ALTER TABLE users
    MODIFY COLUMN phone VARCHAR(30) NULL,
    MODIFY COLUMN password_hash VARCHAR(255) NULL,
    MODIFY COLUMN role ENUM('ADMIN', 'SELLER', 'BUYER') NOT NULL DEFAULT 'BUYER';

-- Pemeriksaan setelah update:
SELECT id, name, email, role, created_at
FROM users
ORDER BY id DESC;
