<?php
if (session_status() !== PHP_SESSION_ACTIVE) { session_start(); }
function e($value): string { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }
function rupiah($amount): string { return 'Rp ' . number_format((float)$amount, 0, ',', '.'); }
function app_config(): array { static $cfg = null; if ($cfg === null) { $cfg = require __DIR__ . '/../config/config.php'; } return $cfg; }
function url(string $path = ''): string {
    // Jika base_url diisi (misalnya saat hosting), gunakan nilai tersebut.
    $base = rtrim((string) (app_config()['base_url'] ?? ''), '/');
    if ($base !== '') {
        return $base . '/' . ltrim($path, '/');
    }

    // Deteksi folder utama project dari URL script yang sedang dibuka.
    // Hilangkan folder halaman internal agar link tetap menuju root project,
    // baik saat halaman dibuka dari /auth, /admin, /seller, maupun /buyer.
    $scriptName = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '/');
    $scriptDir = rtrim(str_replace('\\', '/', dirname($scriptName)), '/');
    $scriptDir = preg_replace('~/(auth|admin|seller|buyer)$~', '', $scriptDir);
    if ($scriptDir === '.' || $scriptDir === '/') {
        $scriptDir = '';
    }

    return $scriptDir . '/' . ltrim($path, '/');
}
function redirect(string $path): never { header('Location: ' . url($path)); exit; }
function set_flash(string $type, string $message): void { $_SESSION['flash'] = ['type'=>$type, 'message'=>$message]; }
function get_flash(): ?array { $f = $_SESSION['flash'] ?? null; unset($_SESSION['flash']); return $f; }
function csrf_token(): string { if (empty($_SESSION['csrf_token'])) { $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); } return $_SESSION['csrf_token']; }
function csrf_field(): string { return '<input type="hidden" name="csrf_token" value="' . e(csrf_token()) . '">'; }
function verify_csrf(): void { if ($_SERVER['REQUEST_METHOD'] === 'POST') { $sent = $_POST['csrf_token'] ?? ''; if (!is_string($sent) || !hash_equals(csrf_token(), $sent)) { http_response_code(419); exit('Sesi formulir kedaluwarsa. Silakan kembali dan coba lagi.'); } } }
function current_user(): ?array { return $_SESSION['user'] ?? null; }
function current_admin(): ?array { $u=current_user(); if ($u) return (($u['role']??'')==='ADMIN') ? $u : null; return $_SESSION['admin'] ?? null; }
function current_seller(): ?array { $u=current_user(); return ($u && ($u['role']??'')==='SELLER') ? $u : null; }
function current_buyer(): ?array { $u=current_user(); return ($u && ($u['role']??'')==='BUYER') ? $u : null; }
function require_role(string $role): void { $u=current_user(); if (!$u || ($u['role']??'')!==$role) { set_flash('warning', 'Silakan login dengan akun '.strtolower($role).' terlebih dahulu.'); redirect('auth/login.php?role='.strtolower($role)); } }
function require_admin(): void { if (!current_admin()) { set_flash('warning', 'Silakan login sebagai admin terlebih dahulu.'); redirect('admin/login.php'); } }
function auth_redirect(): void { $u=current_user(); if (!$u) { redirect('index.php'); } if ($u['role']==='ADMIN') redirect('admin/dashboard.php'); if ($u['role']==='SELLER') redirect('seller/dashboard.php'); redirect('index.php'); }
function product_image(?string $image): string { if (!$image) return url('assets/img/placeholder.svg'); if (preg_match('~^https?://~i', $image)) return $image; return url('uploads/' . rawurlencode(basename($image))); }
function cart_count(): int { return array_sum(array_map('intval', $_SESSION['cart'] ?? [])); }
function get_cart_products(mysqli $conn): array {
    $cart = $_SESSION['cart'] ?? []; if (!$cart) return [];
    $ids = array_values(array_filter(array_map('intval', array_keys($cart)), fn($id)=>$id>0)); if (!$ids) return [];
    $placeholders = implode(',', array_fill(0, count($ids), '?')); $types = str_repeat('i', count($ids));
    $stmt = $conn->prepare("SELECT id,name,description,price,stock,image FROM products WHERE is_active=1 AND id IN ($placeholders)");
    $stmt->bind_param($types, ...$ids); $stmt->execute(); $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC); $stmt->close();
    $out=[]; foreach($rows as $row){ $id=(int)$row['id']; $qty=max(1,(int)($cart[$id]??1)); $row['quantity']=min($qty,(int)$row['stock']); $row['subtotal']=$row['quantity']*(float)$row['price']; $out[]=$row; }
    return $out;
}
function render_header(string $title = 'PasarKita'): void { $cfg=app_config(); $flash=get_flash(); ?>
<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title><?=e($title)?> - <?=e($cfg['app_name']??'PasarKita')?></title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"><link href="<?=e(url('assets/css/style.css'))?>" rel="stylesheet"></head><body>
<nav class="navbar navbar-expand-lg sticky-top"><div class="container"><a class="navbar-brand d-flex align-items-center gap-2 fw-bold" href="<?=e(url('index.php'))?>"><span class="brand-mark">PK</span><span>PasarKita</span></a><button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav"><span class="navbar-toggler-icon"></span></button><div class="collapse navbar-collapse" id="mainNav"><ul class="navbar-nav ms-auto align-items-lg-center gap-lg-2"><li class="nav-item"><a class="nav-link" href="<?=e(url('index.php'))?>">Produk</a></li><li class="nav-item"><a class="nav-link" href="<?=e(url('cart.php'))?>">Keranjang <span class="badge text-bg-success"><?=cart_count()?></span></a></li><?php if(current_user()): $navUser=current_user(); ?><li class="nav-item"><span class="nav-link">Halo, <?=e($navUser['name'])?> (<?=e($navUser['role'])?>)</span></li><?php if($navUser['role']==='ADMIN'): ?><li class="nav-item"><a class="btn btn-outline-success btn-sm" href="<?=e(url('admin/dashboard.php'))?>">Dashboard Admin</a></li><?php elseif($navUser['role']==='SELLER'): ?><li class="nav-item"><a class="btn btn-outline-success btn-sm" href="<?=e(url('seller/dashboard.php'))?>">Dashboard Toko</a></li><?php else: ?><li class="nav-item"><a class="nav-link" href="<?=e(url('buyer/orders.php'))?>">Pesanan Saya</a></li><?php endif; ?><li class="nav-item"><a class="nav-link text-danger" href="<?=e(url('logout.php'))?>">Keluar</a></li><?php else: ?><li class="nav-item"><a class="nav-link" href="<?=e(url('auth/login.php'))?>">Login</a></li><li class="nav-item"><a class="btn btn-brand btn-sm" href="<?=e(url('auth/register.php'))?>">Daftar</a></li><?php endif; ?></ul></div></div></nav><main class="container py-4">
<?php if($flash): ?><div class="alert alert-<?=e($flash['type'])?> alert-dismissible fade show" role="alert"><?=e($flash['message'])?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div><?php endif; ?>
<?php }
function render_footer(): void { ?></main><footer class="footer mt-5 py-4"><div class="container d-flex flex-column flex-md-row justify-content-between gap-2"><div><strong>PasarKita</strong><div class="small-muted">Marketplace sederhana untuk latihan PHP Native, MySQLi, dan Bootstrap.</div></div><div class="small-muted">© <?=date('Y')?> PasarKita</div></div></footer><script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script></body></html><?php }
