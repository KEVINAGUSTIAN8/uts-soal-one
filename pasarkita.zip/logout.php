<?php
require __DIR__ . '/includes/functions.php';

// Hapus autentikasi, tetapi biarkan keranjang belanja tetap tersimpan di sesi.
unset($_SESSION['user'], $_SESSION['admin']);

// Ganti ID sesi untuk mengurangi risiko session fixation.
session_regenerate_id(true);
set_flash('success', 'Kamu berhasil logout. Sampai jumpa kembali!');

redirect('index.php');
